/* End-to-end check: starts the real server and drives four real browser windows
 * through a whole game. Run with: node test/e2e.js [screenshotDir] */
const { spawn } = require('child_process');
const path = require('path');
let chromium;
try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }

const PORT = 3100;
const SHOTS = process.argv[2];
const assert = require('node:assert/strict');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const server = spawn('node', [path.join(__dirname, '..', 'server.js')], { env: Object.assign({}, process.env, { PORT }), stdio: 'inherit' });
  await sleep(800);
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
  const names = ['Amira', 'Ben', 'Chloe', 'Dev'];
  const pages = [];
  const errors = [];
  for (const n of names) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
    await ctx.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
    const page = await ctx.newPage();
    page.on('pageerror', (e) => errors.push(n + ': ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/fonts|ERR_(NAME|INTERNET|CONNECTION|TUNNEL|FAILED)/i.test(m.text())) errors.push(n + ' console: ' + m.text()); });
    pages.push(page);
  }
  const shot = async (page, name) => { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: true }); };

  // Create + join
  const [host, ...others] = pages;
  await host.goto('http://localhost:' + PORT);
  await shot(host, '01-home');
  await host.fill('#h-name', names[0]);
  await host.click('[data-act=create]');
  await host.waitForSelector('.bigcode');
  const code = (await host.textContent('.bigcode')).trim();
  assert.match(code, /^[A-Z]{4}$/);
  for (let i = 0; i < others.length; i++) {
    await others[i].goto('http://localhost:' + PORT + '/?code=' + code);
    await others[i].fill('#h-name', names[i + 1]);
    await others[i].click('[data-act=join]');
    await others[i].waitForSelector('.bigcode');
  }
  await host.waitForFunction(() => document.querySelectorAll('#lb-players .person').length === 4);

  // Duplicate name is refused
  const dctx = await browser.newContext();
  await dctx.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  const dup = await dctx.newPage();
  await dup.goto('http://localhost:' + PORT + '/?code=' + code);
  await dup.fill('#h-name', 'amira');
  await dup.click('[data-act=join]');
  await dup.waitForFunction(() => document.querySelector('#h-err').textContent.includes('taken'));
  await dup.close();

  // Settings: category Animal, 2 knowers, 2 rounds
  await host.click('[data-act=setCategory][data-v=animal]');
  await host.waitForSelector('[data-act=setCategory][data-v=animal][aria-pressed=true]');
  await host.click('[data-act=step][data-f=knowers][data-d="1"]');
  await host.waitForFunction(() => document.querySelector('#lb-settings .stepper output').textContent.trim() === '2');
  for (let i = 0; i < 4; i++) {
    await host.click('[data-act=step][data-f=rounds][data-d="-1"]');
    await sleep(60);
  }
  await host.waitForFunction(() => document.querySelectorAll('#lb-settings .stepper output')[1].textContent.trim() === '2');
  await shot(host, '02-lobby-host');
  await shot(others[0], '03-lobby-guest');
  assert.ok((await others[0].textContent('#lb-settings')).includes('Animal'));
  await host.click('[data-act=start]');

  // Play both rounds
  for (let round = 0; round < 2; round++) {
    for (let step = 0; step < 2; step++) {
      let acted = false;
      for (let tries = 0; tries < 80 && !acted; tries++) {
        for (const p of pages) {
          if (await p.$('#q-in')) {
            if (round === 0 && step === 0) await shot(p, '04-guesser-asks');
            await p.fill('#q-in', 'Is it bigger than a dog?');
            await p.click('[data-act=ask]');
            acted = true; break;
          }
          if (await p.$('#a-in')) {
            if (round === 0 && step === 1) await shot(p, '05-knower-answers');
            await p.fill('#a-in', 'Yes, quite a lot bigger');
            await p.click('[data-act=answer]');
            acted = true; break;
          }
        }
        if (!acted) await sleep(100);
      }
      assert.ok(acted, 'someone should be able to act');
      await sleep(250);
    }
  }
  for (const p of pages) await p.waitForSelector('#gs-head', { timeout: 5000 });

  // Find knowers (they have a Show object button) and read their secrets
  const roles = [];
  for (const p of pages) {
    const k = await p.$('[data-act=toggleReveal]');
    let object = null;
    if (k) { await k.click(); await p.waitForSelector('.secret .word'); object = (await p.textContent('.secret .word')).trim(); }
    roles.push({ page: p, object });
  }
  const knowers = roles.filter((r) => r.object);
  const guessers = roles.filter((r) => !r.object);
  assert.equal(knowers.length, 2);
  assert.equal(guessers.length, 2);
  assert.notEqual(knowers[0].object, knowers[1].object);
  await shot(knowers[0].page, '06-knower-guessing');
  await shot(guessers[0].page, '07-guessing');

  // Guessers: first gets both right (sloppy casing), second gets one right
  const fillGuess = async (page, vals) => {
    const inputs = await page.$$('[data-gk]');
    for (let i = 0; i < inputs.length; i++) await inputs[i].fill(vals[i]);
    await page.click('[data-act=guess]');
  };
  // inputs are in knower order; map knower objects by the label text
  const order = async (page) => (await page.$$eval('.gfield > span', (els) => els.map((e) => e.textContent)));
  const labelsA = await order(guessers[0].page);
  const nameOfObj = {};
  for (const r of knowers) {
    const nm = await r.page.evaluate(() => document.querySelector('#top .codechip') && null);
    nameOfObj[r.object] = nm;
  }
  // knower display names appear in the label "What is X holding?"; match with page identity via the 'You are a knower' pages' own name
  const idents = {};
  for (const [i, p] of pages.entries()) idents[names[i]] = p;
  const objByName = {};
  for (const r of knowers) objByName[names[pages.indexOf(r.page)]] = r.object;
  const answers = (labels, correctBoth, correctFirstOnly) => labels.map((l, i) => {
    const who = names.find((n) => l.includes(n));
    if (correctBoth) return objByName[who].toUpperCase();
    return i === 0 ? objByName[who] : 'xxxxxxxx';
  });
  await fillGuess(guessers[0].page, answers(labelsA, true));
  await guessers[0].page.waitForSelector('.lock');
  const labelsB = await order(guessers[1].page);
  await fillGuess(guessers[1].page, answers(labelsB, false));

  await host.waitForSelector('.winner', { timeout: 5000 });
  await sleep(300);
  await shot(host, '08-results');
  const text = await host.textContent('#rs');
  assert.ok(text.includes(knowers[0].object) && text.includes(knowers[1].object), 'results reveal the objects');

  // Scores: guesser A has 2, guesser B has at least 0..1, knowers have 1
  const scores = await host.$$eval('.rank', (rows) => rows.map((r) => ({ name: r.querySelector('.nm').textContent, pts: Number(r.querySelector('.pts').textContent) })));
  const byName = Object.fromEntries(scores.map((s) => [s.name.replace(' (you)', ''), s.pts]));
  const gA = names[pages.indexOf(guessers[0].page)];
  assert.equal(byName[gA], 2, 'first guesser got both right');
  knowers.forEach((r) => assert.equal(byName[names[pages.indexOf(r.page)]], 1, 'knower gets exactly one point'));

  // Play again
  await host.click('[data-act=again]');
  await host.waitForSelector('.bigcode');
  for (const p of others) await p.waitForSelector('.bigcode');

  // Reconnect: reload a guest, they land back in the party
  await others[1].reload();
  await others[1].waitForSelector('.bigcode', { timeout: 5000 });

  console.log('E2E OK, party', code, errors.length ? '\nPage errors:\n' + errors.join('\n') : '');
  await browser.close();
  server.kill();
  process.exit(errors.length ? 1 : 0);
})().catch((e) => { console.error('E2E FAILED:', e); process.exit(1); });
