const test = require('node:test');
const assert = require('node:assert/strict');
const GTO = require('../public/engine.js');

function setup(n, settings, extra) {
  let t = 1000;
  const store = GTO.createStore(Object.assign({ now: () => t }, extra || {}));
  const host = store.createParty('Host');
  const code = host.code;
  const ids = [host.player.id];
  for (let i = 1; i < n; i++) ids.push(store.join(code, 'P' + i).player.id);
  if (settings) store.act(code, ids[0], 'setSettings', settings);
  return { store, code, ids, host: ids[0], time: (x) => { t = x; }, advance: (x) => { t += x; } };
}

function playRound(s) {
  const v = s.store.view(s.code, s.host);
  const g = v.game;
  s.store.act(s.code, g.guesserId, 'ask', { text: 'Is it big?' });
  s.store.act(s.code, g.knowerId, 'answer', { text: 'Sometimes' });
}

test('default lists have the agreed sizes', () => {
  const L = GTO.LISTS;
  assert.equal(L.food.items.length, 50);
  assert.equal(L.animal.items.length, 50);
  assert.equal(L.country.items.length, 50);
  assert.equal(L.videogame.items.length, 20);
  assert.equal(L.movie.items.length, 20);
});

test('loose matching', () => {
  const usa = GTO.parseItem('USA|united states|america');
  assert.ok(GTO.isMatch('usa', usa));
  assert.ok(GTO.isMatch('The United States', usa));
  assert.ok(GTO.isMatch('america', usa));
  const itl = GTO.parseItem('Italy');
  assert.ok(GTO.isMatch('Itlay', itl)); // swapped letters
  assert.ok(GTO.isMatch('italy ', itl));
  assert.ok(!GTO.isMatch('Iraq', GTO.parseItem('Iran')));
  assert.ok(!GTO.isMatch('Chile', GTO.parseItem('China')));
  assert.ok(GTO.isMatch('pokemon', GTO.parseItem('Pokémon|pokemon')));
  assert.ok(GTO.isMatch('pac man', GTO.parseItem('Pac-Man')));
  assert.ok(GTO.isMatch('fries', GTO.parseItem('French Fries|fries')));
  assert.ok(!GTO.isMatch('', GTO.parseItem('Cat')));
});

test('knowers are capped at half the players and at least one', () => {
  const s = setup(5, { knowers: 50 });
  s.store.act(s.code, s.host, 'start');
  const v = s.store.view(s.code, s.host);
  assert.equal(v.game.knowers.length, 2);
  const s2 = setup(2, { knowers: 3 });
  s2.store.act(s2.code, s2.host, 'start');
  assert.equal(s2.store.view(s2.code, s2.host).game.knowers.length, 1);
});

test('only host starts, and a second player is required', () => {
  const s = setup(2);
  assert.throws(() => s.store.act(s.code, s.ids[1], 'start'), /host/);
  const solo = setup(1);
  assert.throws(() => solo.store.act(solo.code, solo.host, 'start'), /at least 2/);
});

test('a knower object is visible only to that knower', () => {
  const s = setup(6, { knowers: 3 });
  s.store.act(s.code, s.host, 'start');
  const knowerIds = s.store.view(s.code, s.host).game.knowers.map((k) => k.id);
  const objects = [];
  s.ids.forEach((id) => {
    const v = s.store.view(s.code, id);
    if (knowerIds.includes(id)) { assert.ok(v.game.myObject); objects.push(v.game.myObject); }
    else assert.equal(v.game.myObject, null);
    assert.ok(!JSON.stringify(v).includes('"keys"'));
  });
  assert.equal(new Set(objects).size, 3, 'each knower has a different object');
  // Nobody else's view leaks any knower object text
  s.ids.filter((id) => !knowerIds.includes(id)).forEach((id) => {
    const json = JSON.stringify(s.store.view(s.code, id));
    objects.forEach((o) => assert.ok(!json.includes(o) || o.length < 3, 'object leaked: ' + o));
  });
});

test('guessers rotate so everyone asks before anyone repeats; knowers never ask', () => {
  const s = setup(6, { knowers: 2, rounds: 8 });
  s.store.act(s.code, s.host, 'start');
  const knowerIds = s.store.view(s.code, s.host).game.knowers.map((k) => k.id);
  const guessers = [];
  for (let i = 0; i < 4; i++) {
    const g = s.store.view(s.code, s.host).game;
    guessers.push(g.guesserId);
    assert.ok(!knowerIds.includes(g.guesserId));
    assert.ok(knowerIds.includes(g.knowerId));
    playRound(s);
  }
  assert.equal(new Set(guessers).size, 4, 'first four rounds use all four guessers');
});

test('questions are asked to the knowers in turn', () => {
  const s = setup(6, { knowers: 3, rounds: 6 });
  s.store.act(s.code, s.host, 'start');
  const asked = [];
  for (let i = 0; i < 3; i++) { asked.push(s.store.view(s.code, s.host).game.knowerId); playRound(s); }
  assert.equal(new Set(asked).size, 3);
});

test('only the current guesser asks and only the asked knower answers', () => {
  const s = setup(4, { rounds: 3 });
  s.store.act(s.code, s.host, 'start');
  const g = s.store.view(s.code, s.host).game;
  const other = s.ids.find((i) => i !== g.guesserId && i !== g.knowerId);
  assert.throws(() => s.store.act(s.code, other, 'ask', { text: 'x' }), /not your turn/);
  assert.throws(() => s.store.act(s.code, g.knowerId, 'answer', { text: 'x' }), /not being asked/);
  s.store.act(s.code, g.guesserId, 'ask', { text: 'Is it red?' });
  assert.throws(() => s.store.act(s.code, g.guesserId, 'ask', { text: 'again?' }), /not your turn/);
  assert.throws(() => s.store.act(s.code, other, 'answer', { text: 'x' }), /not being asked/);
  s.store.act(s.code, g.knowerId, 'answer', { text: 'No' });
});

test('rounds mode: game moves to guessing after the last round', () => {
  const s = setup(4, { endMode: 'rounds', rounds: 2 });
  s.store.act(s.code, s.host, 'start');
  playRound(s);
  assert.equal(s.store.view(s.code, s.host).phase, 'playing');
  playRound(s);
  assert.equal(s.store.view(s.code, s.host).phase, 'guessing');
});

test('time mode: unlimited rounds, the round in progress finishes after time is up', () => {
  const s = setup(4, { endMode: 'time', minutes: 1 });
  s.store.act(s.code, s.host, 'start');
  for (let i = 0; i < 5; i++) playRound(s);
  assert.equal(s.store.view(s.code, s.host).phase, 'playing');
  const g = s.store.view(s.code, s.host).game;
  s.store.act(s.code, g.guesserId, 'ask', { text: 'Last one?' });
  s.advance(61000); // clock runs out mid-round
  assert.equal(s.store.view(s.code, s.host).phase, 'playing');
  s.store.act(s.code, g.knowerId, 'answer', { text: 'Fine' });
  assert.equal(s.store.view(s.code, s.host).phase, 'guessing');
});

test('reroll changes only that knower and notifies through the log', () => {
  const s = setup(6, { knowers: 2 });
  s.store.act(s.code, s.host, 'start');
  const ks = s.store.view(s.code, s.host).game.knowers.map((k) => k.id);
  const before = ks.map((id) => s.store.view(s.code, id).game.myObject);
  s.store.act(s.code, ks[0], 'reroll');
  const after = ks.map((id) => s.store.view(s.code, id).game.myObject);
  assert.notEqual(after[0], before[0]);
  assert.equal(after[1], before[1]);
  assert.notEqual(after[0], after[1]);
  const log = s.store.view(s.code, s.host).game.log;
  assert.equal(log[log.length - 1].type, 'reroll');
  const nonKnower = s.ids.find((i) => !ks.includes(i));
  assert.throws(() => s.store.act(s.code, nonKnower, 'reroll'), /Only knowers/);
});

test('scoring: correct guesser +1 each, knower +1 once if anyone is right', () => {
  const s = setup(5, { knowers: 2, rounds: 1 });
  s.store.act(s.code, s.host, 'start');
  playRound(s);
  const v = s.store.view(s.code, s.host);
  assert.equal(v.phase, 'guessing');
  const [k1, k2] = v.game.knowers.map((k) => k.id);
  const obj = {};
  [k1, k2].forEach((k) => { obj[k] = s.store.view(s.code, k).game.myObject; });
  const guessers = s.ids.filter((i) => ![k1, k2].includes(i));
  assert.throws(() => s.store.act(s.code, k1, 'guess', { guesses: {} }), /Knowers do not guess/);
  // guesser A gets both right (loose casing), guesser B gets k1 right, guesser C is wrong
  s.store.act(s.code, guessers[0], 'guess', { guesses: { [k1]: obj[k1].toUpperCase(), [k2]: obj[k2] } });
  s.store.act(s.code, guessers[1], 'guess', { guesses: { [k1]: obj[k1], [k2]: 'zzzzzz' } });
  assert.throws(() => s.store.act(s.code, guessers[1], 'guess', { guesses: {} }), /already/);
  s.store.act(s.code, guessers[2], 'guess', { guesses: { [k1]: 'nope', [k2]: 'nope' } });
  const r = s.store.view(s.code, s.host);
  assert.equal(r.phase, 'results');
  const byId = {};
  r.players.forEach((p) => { byId[p.id] = p.score; });
  assert.equal(byId[guessers[0]], 2);
  assert.equal(byId[guessers[1]], 1);
  assert.equal(byId[guessers[2]], 0);
  assert.equal(byId[k1], 1, 'knower gets one point even though two guessers were right');
  assert.equal(byId[k2], 1);
  assert.deepEqual(r.results.winners, [guessers[0]]);
  assert.equal(r.players.find((p) => p.id === guessers[0]).wins, 1);
});

test('knower with nobody right scores nothing; zero-score game has no winner', () => {
  const s = setup(3, { knowers: 1, rounds: 1 });
  s.store.act(s.code, s.host, 'start');
  playRound(s);
  const v = s.store.view(s.code, s.host);
  const k = v.game.knowers[0].id;
  s.ids.filter((i) => i !== k).forEach((id) => s.store.act(s.code, id, 'guess', { guesses: { [k]: 'wrong' } }));
  const r = s.store.view(s.code, s.host);
  assert.equal(r.phase, 'results');
  assert.equal(r.players.find((p) => p.id === k).score, 0);
  assert.deepEqual(r.results.winners, []);
});

test('play again keeps the win tally and resets scores', () => {
  const s = setup(3, { knowers: 1, rounds: 1 });
  for (let g = 0; g < 2; g++) {
    s.store.act(s.code, s.host, 'start');
    playRound(s);
    const k = s.store.view(s.code, s.host).game.knowers[0].id;
    const obj = s.store.view(s.code, k).game.myObject;
    const guesser = s.ids.find((i) => i !== k);
    const other = s.ids.find((i) => i !== k && i !== guesser);
    s.store.act(s.code, guesser, 'guess', { guesses: { [k]: obj } });
    s.store.act(s.code, other, 'guess', { guesses: { [k]: '' } });
    assert.equal(s.store.view(s.code, s.host).phase, 'results');
    s.store.act(s.code, s.host, 'playAgain');
    const v = s.store.view(s.code, s.host);
    assert.equal(v.phase, 'lobby');
    assert.ok(v.players.every((p) => p.score === 0));
  }
  // each game ends 1-1 (guesser and knower tie), so both share the win each time
  const total = s.store.view(s.code, s.host).players.reduce((a, p) => a + p.wins, 0);
  assert.equal(total, 4);
});

test('custom lists: needs enough items, objects come from the list', () => {
  const s = setup(4, { category: 'custom', knowers: 2, custom: { name: 'Kitchen', text: 'Spoon\nFork' } });
  assert.throws(() => s.store.act(s.code, s.host, 'start'), /at least 3/);
  s.store.act(s.code, s.host, 'setSettings', { custom: { text: 'Spoon\nFork\nKnife, Whisk' } });
  s.store.act(s.code, s.host, 'start');
  const v = s.store.view(s.code, s.host);
  assert.equal(v.game.categoryName, 'Kitchen');
  const objs = v.game.knowers.map((k) => s.store.view(s.code, k.id).game.myObject);
  objs.forEach((o) => assert.ok(['Spoon', 'Fork', 'Knife', 'Whisk'].includes(o)));
});

test('host controls: skip turn and end game', () => {
  const s = setup(4, { rounds: 5 });
  s.store.act(s.code, s.host, 'start');
  const g1 = s.store.view(s.code, s.host).game;
  assert.throws(() => s.store.act(s.code, s.ids.find((i) => i !== s.host), 'skip'), /host/);
  s.store.act(s.code, s.host, 'skip');
  const g2 = s.store.view(s.code, s.host).game;
  assert.equal(g2.round, g1.round + 1);
  s.store.act(s.code, s.host, 'endNow');
  assert.equal(s.store.view(s.code, s.host).phase, 'guessing');
});

test('names are unique, joining mid-game is refused, resume works', () => {
  const s = setup(3);
  assert.throws(() => s.store.join(s.code, 'p1'), /taken/);
  s.store.act(s.code, s.host, 'start');
  assert.throws(() => s.store.join(s.code, 'Late'), /already started/);
  const p = s.store.parties.get(s.code).players[1];
  assert.equal(s.store.resume(s.code, p.token).player.id, p.id);
  assert.throws(() => s.store.resume(s.code, 'bad'), /no longer/);
});

test('a disconnected guesser is skipped after the grace period', () => {
  const s = setup(4, { rounds: 5 }, { grace: 5000 });
  s.store.act(s.code, s.host, 'start');
  const g = s.store.view(s.code, s.host).game;
  s.store.setConnected(s.code, g.guesserId, false);
  s.advance(4000);
  assert.deepEqual(s.store.tick(), []);
  s.advance(2000);
  assert.deepEqual(s.store.tick(), [s.code]);
  assert.equal(s.store.view(s.code, s.host).game.round, g.round + 1);
});

test('guessing finishes when everyone present has submitted (absent players do not block)', () => {
  const s = setup(4, { knowers: 1, rounds: 1 }, { grace: 1000 });
  s.store.act(s.code, s.host, 'start');
  playRound(s);
  const k = s.store.view(s.code, s.host).game.knowers[0].id;
  const guessers = s.ids.filter((i) => i !== k);
  s.store.act(s.code, guessers[0], 'guess', { guesses: { [k]: 'a' } });
  s.store.act(s.code, guessers[1], 'guess', { guesses: { [k]: 'b' } });
  s.store.setConnected(s.code, guessers[2], false);
  s.advance(2000);
  s.store.tick();
  assert.equal(s.store.view(s.code, s.host).phase, 'results');
});
