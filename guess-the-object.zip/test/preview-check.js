/* Plays the bot preview in a real browser: user is host with 4 bots, 3 rounds. */
let chromium;
try { ({ chromium } = require('playwright')); } catch (e) { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
const path = require('path');
const assert = require('node:assert/strict');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SHOTS = process.argv[2];

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
  for (const scheme of ['light', 'dark']) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto('file://' + path.join(__dirname, '..', 'preview.html'));
    await page.fill('#h-name', 'You');
    if (scheme === 'light' && SHOTS) await page.screenshot({ path: path.join(SHOTS, 'p1-home.png'), fullPage: true });
    await page.click('[data-act=create]');
    await page.waitForSelector('.bigcode');
    assert.equal(await page.$$eval('#lb-players .person', (e) => e.length), 5);
    await page.click('[data-act=setCategory][data-v=videogame]');
    await page.click('[data-act=step][data-f=knowers][data-d="1"]');
    for (let i = 0; i < 3; i++) await page.click('[data-act=step][data-f=rounds][data-d="-1"]');
    if (scheme === 'light' && SHOTS) await page.screenshot({ path: path.join(SHOTS, 'p2-lobby.png'), fullPage: true });
    await page.click('[data-act=start]');
    await page.waitForSelector('#pl-status');
    let shotPlay = false;
    // play until the guessing phase; answer/ask whenever the user is asked
    const t0 = Date.now();
    while (!(await page.$('#gs-head')) && Date.now() - t0 < 90000) {
      if (await page.$('#q-in')) { await page.fill('#q-in', 'Can you play it on a phone?'); await page.click('[data-act=ask]'); }
      else if (await page.$('#a-in')) { await page.fill('#a-in', 'Yes'); await page.click('[data-act=answer]'); }
      if (!shotPlay && SHOTS && scheme === 'dark' && (await page.$('.role.g'))) { await sleep(2500); await page.screenshot({ path: path.join(SHOTS, 'p3-play-dark.png'), fullPage: true }); shotPlay = true; }
      await sleep(300);
    }
    assert.ok(await page.$('#gs-head'), 'reached guessing');
    if (await page.$('[data-gk]')) {
      for (const i of await page.$$('[data-gk]')) await i.fill('pokemon');
      await page.click('[data-act=guess]');
    }
    await page.waitForSelector('.winner', { timeout: 20000 });
    if (SHOTS) await page.screenshot({ path: path.join(SHOTS, 'p4-results-' + scheme + '.png'), fullPage: true });
    await page.click('[data-act=again]');
    await page.waitForSelector('.bigcode');
    console.log(scheme, 'preview OK', errors.length ? errors : '');
    assert.equal(errors.length, 0);
    await ctx.close();
  }
  await browser.close();
})().catch((e) => { console.error('PREVIEW CHECK FAILED', e); process.exit(1); });
