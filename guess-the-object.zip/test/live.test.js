/* Plays whole games against the real server with several simulated phones. */
process.env.RECONNECT_GRACE_MS = '400';
const assert = require('assert');
const http = require('http');
const { server, parties } = require('../server');
const Words = require('../public/words.js');

let base;
let passed = 0;
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, label, ms = 4000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (fn()) return; await sleep(15); }
  throw new Error('Timed out waiting for: ' + label);
}
async function test(name, fn) {
  try { await fn(); passed++; console.log('  ok  ' + name); }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + (e && e.stack || e)); process.exitCode = 1; }
}

class Phone {
  constructor(name) {
    this.name = name;
    this.pid = (name + '-session-id-0123456789').slice(0, 24);
    this.view = null;
    this.views = [];
    this.code = null;
  }
  async post(action, body) {
    const r = await fetch(base + '/api/' + action, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ pid: this.pid, code: this.code }, body))
    });
    return Object.assign({ status: r.status }, await r.json());
  }
  async open() {
    this.abort = new AbortController();
    const r = await fetch(base + '/events?code=' + this.code + '&pid=' + this.pid, { signal: this.abort.signal });
    assert.strictEqual(r.status, 200);
    this.reader = r.body.getReader();
    (async () => {
      const dec = new TextDecoder();
      let buf = '';
      try {
        for (;;) {
          const { value, done } = await this.reader.read();
          if (done) return;
          buf += dec.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const chunk = buf.slice(0, i);
            buf = buf.slice(i + 2);
            const ev = /event: (\w+)/.exec(chunk);
            const data = /data: (.*)/.exec(chunk);
            if (ev && ev[1] === 'state' && data) { this.view = JSON.parse(data[1]); this.views.push(data[1]); }
          }
        }
      } catch (e) { /* stream closed */ }
    })();
    await until(() => this.view, this.name + ' first state');
  }
  close() { if (this.abort) this.abort.abort(); }
  async create() { const r = await this.post('create', { name: this.name, code: undefined }); assert.ok(r.ok, r.error); this.code = r.code; await this.open(); }
  async join(code) { this.code = code; const r = await this.post('join', { name: this.name }); assert.ok(r.ok, r.error); await this.open(); }
}

function rawGet(path) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: server.address().port, path }, res => {
      let body = '';
      res.on('data', c => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    }).on('error', reject);
  });
}

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
  console.log('Server on ' + base);

  await test('serves the app and refuses to leave the public folder', async () => {
    const home = await rawGet('/');
    assert.strictEqual(home.status, 200);
    assert.match(home.body, /Guess the Object/);
    assert.strictEqual((await rawGet('/app.js')).status, 200);
    for (const sneaky of ['/%2e%2e/server.js', '/..%2fserver.js', '/../game.js', '/%2e%2e%2f%2e%2e%2fetc/passwd']) {
      const r = await rawGet(sneaky);
      assert.ok(r.status === 403 || r.status === 404, sneaky + ' returned ' + r.status);
      assert.ok(!/createServer|module\.exports|root:/.test(r.body), sneaky + ' leaked a file');
    }
    assert.strictEqual((await rawGet('/nope.txt')).status, 404);
  });

  await test('rejects bad sessions, unknown codes and strangers', async () => {
    const p = new Phone('Nobody');
    let r = await p.post('create', { name: 'x', pid: 'short' });
    assert.strictEqual(r.status, 400);
    r = await p.post('join', { code: 'ZZZZ', name: 'x' });
    assert.match(r.error, /No party/);
    r = await p.post('start', { code: 'ZZZZ' });
    assert.match(r.error, /not in a party/);
    const bad = await fetch(base + '/events?code=ZZZZ&pid=' + p.pid);
    assert.strictEqual(bad.status, 404);
  });

  let host, guests, phones;
  await test('four phones create and join one party', async () => {
    host = new Phone('Amira');
    guests = ['Bilal', 'Chen', 'Dara'].map(n => new Phone(n));
    phones = [host, ...guests];
    await host.create();
    assert.match(host.code, /^[A-HJ-NP-Z]{4}$/);
    for (const g of guests) await g.join(host.code.toLowerCase());
    await until(() => host.view.players.length === 4, 'host sees 4 players');
    const dup = new Phone('amira');
    dup.code = host.code;
    assert.match((await dup.post('join', { name: 'amira' })).error, /taken/);
  });

  await test('only the host can change settings or start', async () => {
    assert.match((await guests[0].post('settings', { category: 'Animal' })).error, /host/i);
    assert.match((await guests[0].post('start', {})).error, /host/i);
    const r = await host.post('settings', { category: 'Movie', knowers: 2, endMode: 'rounds', rounds: 4 });
    assert.ok(r.ok, r.error);
    await until(() => guests[2].view.settings.category === 'Movie', 'guest sees category');
    assert.strictEqual(guests[2].view.settings.rounds, 4);
  });

  await test('a full game plays through with secrets kept', async () => {
    const r = await host.post('start', {});
    assert.ok(r.ok, r.error);
    await until(() => phones.every(p => p.view.phase === 'playing'), 'everyone playing');

    const knowers = phones.filter(p => p.view.game.myObject);
    assert.strictEqual(knowers.length, 2);
    const objects = knowers.map(k => k.view.game.myObject);
    assert.notStrictEqual(objects[0], objects[1]);
    objects.forEach(o => assert.ok(Words.lists.Movie.includes(o)));

    for (let round = 1; round <= 4; round++) {
      await until(() => host.view.game.current && host.view.game.current.stage === 'ask' && host.view.game.round === round, 'round ' + round + ' ask');
      const c = host.view.game.current;
      const guesser = phones.find(p => p.pid === c.guesserId);
      const asked = phones.find(p => p.pid === c.knowerId);
      assert.ok(!guesser.view.game.myObject, 'a knower was asked to ask');
      assert.ok(asked.view.game.myObject, 'a non-knower was asked to answer');

      assert.match((await asked.post('ask', { text: 'hi' })).error, /turn/);
      let a = await guesser.post('ask', { text: 'Is it animated? (' + round + ')' });
      assert.ok(a.ok, a.error);
      await until(() => asked.view.game.current && asked.view.game.current.stage === 'answer', 'answer stage');
      assert.strictEqual(asked.view.game.current.question, 'Is it animated? (' + round + ')');
      if (round === 2) {
        const before = asked.view.game.myObject;
        assert.ok((await asked.post('reroll', {})).ok);
        await until(() => asked.view.game.myObject !== before, 'reroll applied');
        await until(() => phones.every(p => p.view.game.feed.some(f => f.type === 'reroll')), 'everyone notified of reroll');
      }
      a = await asked.post('answer', { text: 'Answer ' + round });
      assert.ok(a.ok, a.error);
    }

    await until(() => phones.every(p => p.view.phase === 'guessing'), 'everyone guessing');
    assert.strictEqual(host.view.game.feed.filter(f => f.type === 'qa').length, 4);

    // Secrecy: nobody ever received another player's object before the results.
    // (A knower who rerolled legitimately saw both of their own objects.)
    const held = p => new Set(p.views.map(v => JSON.parse(v).game && JSON.parse(v).game.myObject).filter(Boolean));
    assert.strictEqual(held(knowers.find(k => k.pid === host.view.game.knowerIds.find(id => held(phones.find(x => x.pid === id)).size === 2)) || knowers[0]).size >= 1, true);
    for (const p of phones) {
      const own = held(p);
      for (const q of phones) {
        if (q === p) continue;
        for (const o of held(q)) {
          if (own.has(o)) continue;
          for (const raw of p.views) {
            if (JSON.parse(raw).phase === 'finished') continue;
            assert.ok(!raw.includes('"' + o + '"'), p.name + ' was sent ' + o + ' before the results');
          }
        }
      }
    }

    // Guessers: one gets everything right (typos allowed), the rest miss.
    const guessers = phones.filter(p => !p.view.game.myObject);
    const ids = host.view.game.knowerIds;
    const truth = Object.fromEntries(knowers.map(k => [k.pid, k.view.game.myObject]));
    assert.ok((await knowers[0].post('guess', { guesses: {} })).error, 'knowers must not guess');
    let g = await guessers[0].post('guess', { guesses: Object.fromEntries(ids.map(id => [id, truth[id].toLowerCase()])) });
    assert.ok(g.ok, g.error);
    assert.match((await guessers[0].post('guess', { guesses: {} })).error, /already/);
    await until(() => host.view.game.submitted.length === 1, 'submission shown');
    assert.strictEqual(host.view.phase, 'guessing');
    g = await guessers[1].post('guess', { guesses: Object.fromEntries(ids.map(id => [id, 'zzzz'])) });
    assert.ok(g.ok, g.error);
    await until(() => phones.every(p => p.view.phase === 'finished'), 'results for everyone');

    const res = host.view.game.results;
    assert.deepStrictEqual(res.perKnower.map(k => k.object).sort(), Object.values(truth).sort());
    const score = id => host.view.players.find(p => p.id === id).score;
    assert.strictEqual(score(guessers[0].pid), 2);
    assert.strictEqual(score(guessers[1].pid), 0);
    knowers.forEach(k => assert.strictEqual(score(k.pid), 1));
    assert.deepStrictEqual(res.winners, [guessers[0].pid]);
    assert.strictEqual(host.view.players.find(p => p.id === guessers[0].pid).wins, 1);
  });

  await test('play again returns everyone to the lobby with wins kept', async () => {
    assert.match((await guests[0].post('again', {})).error, /host/);
    assert.ok((await host.post('again', {})).ok);
    await until(() => phones.every(p => p.view.phase === 'lobby'), 'back in lobby');
    assert.ok(host.view.players.every(p => p.score === 0));
    assert.strictEqual(host.view.players.reduce((n, p) => n + p.wins, 0), 1);
  });

  await test('a refreshed phone gets back in; a vanished one is dropped from the lobby', async () => {
    const bilal = guests[0];
    bilal.close();
    bilal.view = null;
    await sleep(100);
    await bilal.open();
    assert.strictEqual(bilal.view.players.length, 4);
    assert.ok(bilal.view.players.find(p => p.id === bilal.pid).connected);

    guests[2].close();
    await until(() => host.view.players.length === 3, 'Dara dropped after the grace period', 3000);
  });

  await test('time mode: the clock is shared and the game moves to guessing', async () => {
    phones = [host, guests[0], guests[1]];
    assert.ok((await host.post('settings', { endMode: 'time', minutes: 1, knowers: 1, category: 'Food' })).ok);
    assert.ok((await host.post('start', {})).ok);
    await until(() => phones.every(p => p.view.phase === 'playing'), 'playing');
    const g = host.view.game;
    assert.strictEqual(g.endMode, 'time');
    assert.ok(Math.abs(g.deadline - Date.now() - 60000) < 3000, 'deadline is about a minute away');
    assert.strictEqual(g.roundsTotal, null);
    // The host ends the questions early.
    assert.ok((await host.post('endNow', {})).ok);
    await until(() => phones.every(p => p.view.phase === 'guessing'), 'guessing');
    assert.ok((await host.post('endNow', {})).ok);
    await until(() => phones.every(p => p.view.phase === 'finished'), 'finished');
  });

  await test('leaving the party removes you from the lobby for everyone', async () => {
    assert.ok((await host.post('again', {})).ok);
    await until(() => host.view.phase === 'lobby', 'lobby');
    const r = await guests[1].post('leave', {});
    assert.ok(r.ok);
    await until(() => host.view.players.length === 2, 'Chen gone');
  });

  phones.concat(guests).forEach(p => p.close());
  console.log('\n' + passed + ' live tests passed' + (process.exitCode ? ', with failures above' : ''));
  parties.clear();
  server.close();
  setTimeout(() => process.exit(process.exitCode || 0), 100);
})();
