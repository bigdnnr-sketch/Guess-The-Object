/* Demo network for the preview: runs the real game engine in the page and
 * lets four bots play, so one person can try every screen. The live game
 * uses server.js instead and never loads this file. */
(function () {
  'use strict';
  window.GTO_DEMO = true;

  const BOT_NAMES = ['Nora', 'Sam', 'Lea', 'Omar'];
  const QUESTIONS = {
    food: ['Is it sweet?', 'Would you eat it for breakfast?', 'Is it usually served hot?', 'Is it a fruit or a vegetable?', 'Do you need a fork for it?'],
    animal: ['Does it live in water?', 'Can it fly?', 'Is it bigger than a dog?', 'Would you keep it as a pet?', 'Does it have fur?'],
    country: ['Is it in Europe?', 'Does it have a coastline?', 'Is it bigger than France?', 'Is it in the Southern Hemisphere?', 'Is English widely spoken there?'],
    videogame: ['Can you play it on a phone?', 'Is it from Nintendo?', 'Does it have online multiplayer?', 'Is it older than 2010?', 'Is it a shooter?'],
    movie: ['Is it animated?', 'Is it older than 2000?', 'Is it part of a franchise?', 'Did it win Best Picture?', 'Is it a family film?'],
    custom: ['Can you hold it in your hand?', 'Is it bigger than a shoebox?', 'Is it made of metal?', 'Would you find it at home?', 'Do you use it every day?'],
  };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (a) => a[Math.floor(Math.random() * a.length)];

  window.createLocalNet = function () {
    const store = GTO.createStore();
    const L = { state: [], gone: [] };
    let code = null, me = null;
    const timers = {};

    const push = () => {
      if (!code) return;
      let v;
      try { v = store.view(code, me.id); } catch (e) { return; }
      L.state.forEach((f) => f(v));
    };
    const isBot = (id) => { const p = store.parties.get(code); const x = p && p.players.find((q) => q.id === id); return !!(x && x.bot); };

    function later(key, ms, fn) {
      if (timers[key]) return;
      timers[key] = setTimeout(() => {
        delete timers[key];
        try { fn(); } catch (e) { /* the turn moved on */ }
        push();
      }, ms);
    }

    function answerFor(object) {
      const w = object.name;
      const options = [
        'Yes.', 'No.', 'Sort of.', 'Not really.', 'Definitely.',
        'It starts with "' + w[0].toUpperCase() + '".', 'It has ' + w.replace(/[^a-z0-9]/gi, '').length + ' letters.',
        w.indexOf(' ') > 0 ? 'It is more than one word.' : 'It is a single word.',
        'It ends with "' + w[w.length - 1].toLowerCase() + '".',
      ];
      return pick(options);
    }

    function botLoop() {
      const p = store.parties.get(code);
      if (!p || !p.game) return;
      const g = p.game;
      if (p.phase === 'playing') {
        const round = g.round;
        if (g.awaiting === 'question' && isBot(g.guesserId)) {
          const gid = g.guesserId;
          later('q' + round, rnd(1500, 3200), () => {
            if (g.round !== round || g.awaiting !== 'question') return;
            store.act(code, gid, 'ask', { text: pick(QUESTIONS[g.categoryKey] || QUESTIONS.custom) });
          });
        }
        if (g.awaiting === 'answer' && isBot(g.knowerId)) {
          const kid = g.knowerId;
          later('a' + round, rnd(1500, 3000), () => {
            if (g.round !== round || g.awaiting !== 'answer') return;
            const k = g.knowers.find((x) => x.id === kid);
            store.act(code, kid, 'answer', { text: answerFor(k.object) });
          });
        }
      } else if (p.phase === 'guessing') {
        p.players.forEach((b) => {
          if (!b.bot || g.guesses[b.id] || g.knowers.some((k) => k.id === b.id)) return;
          later('g' + b.id, rnd(2000, 6000), () => {
            const guesses = {};
            g.knowers.forEach((k) => {
              guesses[k.id] = Math.random() < 0.45 ? k.object.name : pick(g.items).name;
            });
            store.act(code, b.id, 'guess', { guesses });
          });
        });
      }
    }

    return {
      hasSession: () => false,
      async create(name) {
        const r = store.createParty(name);
        code = r.code; me = r.player;
        BOT_NAMES.forEach((n) => store.join(code, n, { bot: true }));
        setInterval(botLoop, 500);
        push();
        return { code };
      },
      async join() { throw new Error('This preview has no other devices. Start a demo party instead.'); },
      async act(type, data) { store.act(code, me.id, type, data); push(); },
      leave() { /* nothing stored */ },
      onState: (f) => L.state.push(f),
      onGone: (f) => L.gone.push(f),
    };
  };
})();
