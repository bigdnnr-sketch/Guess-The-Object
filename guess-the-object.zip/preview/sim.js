/* Offline stand-in for the server, used only by the preview page.
   It runs the real game engine in the browser and plays four simulated
   friends, so the real interface can be tried without a server. */
window.Transport = (function () {
  'use strict';
  const E = window.GameEngine;
  const Words = window.GameWords;
  const FAST = /[?&]fast/.test(location.search);
  const ME = 'you-preview-session';
  const handlers = { state: [], gone: [], lost: [] };
  const BOTS = [
    { id: 'bot-maya-preview', name: 'Maya', skill: 0.75 },
    { id: 'bot-omar-preview', name: 'Omar', skill: 0.45 },
    { id: 'bot-lena-preview', name: 'Lena', skill: 0.6 },
    { id: 'bot-sam-preview', name: 'Sam', skill: 0.3 }
  ];

  const QUESTIONS = {
    Food: ['Would you eat it for breakfast?', 'Is it usually served hot?', 'Does it come from a plant?', 'Can you eat it with your hands?'],
    Animal: ['Does it live in water?', 'Is it bigger than a person?', 'Does it have fur?', 'Can it fly?'],
    Country: ['Is it in Europe?', 'Does it have a coastline?', 'Is it bigger than France?', 'Do they drive on the left?'],
    'Video Game': ['Can you play it online with friends?', 'Is it older than 2010?', 'Do you play from a first-person view?', 'Is the main character a person?'],
    Movie: ['Is it animated?', 'Is it part of a series?', 'Did it win Best Picture?', 'Is it older than 2000?'],
    'Custom list': ['Is it something you do indoors?', 'Would it work with a big group?', 'Is it hard to do?', 'Would you do it on a weekend?']
  };
  const ANSWERS = ['Yes.', 'No.', 'Not really.', 'Sometimes, depending on who you ask.', 'Yes, most people have tried it.', 'Kind of, yes.', 'Definitely not.'];

  let party = null;
  let botTimer = null;
  const rerolled = new Set();
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const wait = (min, max) => (FAST ? 250 : min + Math.random() * (max - min));

  function fresh() {
    clearTimeout(botTimer);
    botTimer = null;
    rerolled.clear();
    party = new E.Party('HZRB', ME, 'You');
    BOTS.forEach(b => party.addPlayer(b.id, b.name));
    party.setSettings(ME, { category: 'Food', knowers: 2, endMode: 'rounds', rounds: 5 });
  }

  function push() {
    handlers.state.forEach(fn => fn(party.view(ME)));
    scheduleBots();
  }

  function botFor(id) { return BOTS.find(b => b.id === id); }

  function nextBotAction() {
    if (party.phase === 'playing' && party.game.current) {
      const c = party.game.current;
      const asker = botFor(c.guesserId);
      const asked = botFor(c.knowerId);
      if (c.stage === 'ask' && asker) {
        return { delay: wait(2200, 3600), run: () => party.ask(asker.id, pick(QUESTIONS[party.game.category] || QUESTIONS['Custom list'])) };
      }
      if (c.stage === 'answer' && asked) {
        return {
          delay: wait(2400, 4000),
          run: () => {
            // One knower draws a new object once, so the notice can be seen.
            if (!rerolled.size && party.game.round === 2) { rerolled.add(asked.id); party.reroll(asked.id); return; }
            party.answer(asked.id, pick(ANSWERS));
          }
        };
      }
    }
    if (party.phase === 'guessing') {
      const bot = BOTS.find(b => party.get(b.id) && !party.isKnower(b.id) && !party.game.guesses[b.id]);
      if (bot) {
        return {
          delay: wait(1800, 3200),
          run: () => {
            const map = {};
            party.game.knowers.forEach(k => {
              if (Math.random() < bot.skill) map[k.id] = k.object;
              else map[k.id] = pick(party.pool().filter(o => o !== k.object));
            });
            party.submitGuesses(bot.id, map);
          }
        };
      }
    }
    return null;
  }

  function scheduleBots() {
    clearTimeout(botTimer);
    botTimer = null;
    const next = nextBotAction();
    if (!next) return;
    botTimer = setTimeout(() => {
      botTimer = null;
      try { next.run(); } catch (e) { console.warn('preview bot skipped:', e.message); }
      push();
    }, next.delay);
  }

  const run = {
    settings: p => party.setSettings(ME, p),
    start: () => party.start(ME),
    ask: p => party.ask(ME, p.text),
    answer: p => party.answer(ME, p.text),
    reroll: () => party.reroll(ME),
    skip: () => party.skipTurn(ME),
    endNow: () => party.endNow(ME),
    guess: p => party.submitGuesses(ME, p.guesses),
    again: () => party.playAgain(ME),
    leave: () => { fresh(); }
  };

  function emit(event, payload, cb) {
    let res = { ok: true };
    try {
      if (!run[event]) throw E.userError('Not available in the preview.');
      run[event](payload || {});
    } catch (e) {
      res = { error: e.user ? e.message : 'Something went wrong.' };
    }
    if (cb) cb(res);
    if (res.ok) push();
  }

  function connect() { if (!party) fresh(); push(); }
  function disconnect() {}
  function on(name, fn) { handlers[name].push(fn); }

  // Clock for time mode, and the restart link in the preview note.
  setInterval(() => { if (party && party.tick()) push(); }, 1000);
  document.addEventListener('click', e => {
    if (e.target.closest('[data-act="restart"]')) { fresh(); push(); }
  });
  window.PREVIEW_NOTE = () => '<div class="app" style="padding-bottom:0"><div class="preview-note">Preview. Maya, Omar, Lena and Sam are simulated players.<button class="link" data-act="restart">Restart</button></div></div>';

  fresh();
  return { emit, on, connect, disconnect };
})();
