/* Bundles the real client and engine, plus the simulated players, into one page. */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const script = src => {
  if (/<\/script/i.test(src)) throw new Error('a script contains </script');
  return '<script>\n' + src + '\n</script>';
};

const html = `<meta charset="utf-8">
<title>Guess the Object</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600..800&family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;700&display=swap">
<style>
${read('public/style.css')}
</style>
<div id="app"></div>
<div id="toast" role="status" aria-live="polite"></div>
${script(read('public/words.js'))}
${script(read('game.js'))}
${script(read('preview/sim.js'))}
${script(read('public/app.js'))}
${script('window.Transport.connect();')}
`;

const out = path.join(__dirname, 'preview.html');
fs.writeFileSync(out, html);
console.log('wrote ' + out + ' (' + Math.round(html.length / 1024) + ' KB)');
